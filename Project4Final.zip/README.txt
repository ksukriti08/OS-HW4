Round robin was used for the eviction strategy. 
Page table entries were stored in 3 bytes. First byte included valid, protection, present and reference bits, 2nd byte had VPN and 3rd byte had the frame number.

I modified the starter code to make physmem[] an integer array. I write to the disk using fprintf and load data from disk using fscanf. 

My output of the two tests provided to us are under the test folder. These files are named HW4_test1.txt and HW4_test2.txt. 
